//
// Generated file, do not edit!
//
// This file defines symbols contributed by the currently active project features,
// and it is regenerated every time a project feature is enabled or disabled.
// See the Project Features dialog in the IDE, and opp_featuretool.
//
#ifndef WITH_CAN_COMMON
#define WITH_CAN_COMMON
#endif

#ifndef WITH_FR_COMMON
#define WITH_FR_COMMON
#endif

